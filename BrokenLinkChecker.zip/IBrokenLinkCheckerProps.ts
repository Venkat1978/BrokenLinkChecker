import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface IBrokenLinkCheckerProps {
  description: string;
  context: WebPartContext;
}
