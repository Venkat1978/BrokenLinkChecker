# Broken Link Checker SPFx Web Part - Complete Setup Guide

## 📁 Project Structure

```
broken-link-checker/
├── config/
│   ├── config.json
│   ├── package-solution.json
│   └── serve.json
├── src/
│   └── webparts/
│       └── brokenLinkChecker/
│           ├── components/
│           │   ├── BrokenLinkChecker.tsx
│           │   ├── BrokenLinkChecker.module.scss
│           │   ├── IBrokenLinkCheckerProps.ts
│           │   └── IBrokenLinkCheckerState.ts
│           ├── loc/
│           │   ├── en-us.js
│           │   └── mystrings.d.ts
│           ├── BrokenLinkCheckerWebPart.ts
│           └── BrokenLinkCheckerWebPart.manifest.json
├── package.json
├── tsconfig.json
└── gulpfile.js
```

## 🚀 Quick Start

### Prerequisites

1. **Node.js** - v16.x or v18.x (recommended: v16.20.0)
2. **npm** - v8.x (comes with Node.js)
3. **Gulp CLI** - Install globally:
   ```bash
   npm install -g gulp-cli
   ```
4. **Yeoman & SPFx Generator** (optional, for creating new projects):
   ```bash
   npm install -g yo @microsoft/generator-sharepoint
   ```

### Installation Steps

#### Method 1: Using Provided Files

1. **Create the project structure:**
   ```bash
   mkdir broken-link-checker
   cd broken-link-checker
   ```

2. **Copy all provided files** into the correct folder structure as shown above.

3. **Install dependencies:**
   ```bash
   npm install
   ```

4. **Trust the development certificate:**
   ```bash
   gulp trust-dev-cert
   ```

#### Method 2: Generate from Scratch (Alternative)

1. **Create new SPFx solution:**
   ```bash
   yo @microsoft/sharepoint
   ```

   Answer prompts:
   - Solution name: `broken-link-checker`
   - Target: SharePoint Online only
   - Place files: Current folder
   - Deployment: Tenant-wide
   - Permissions: No
   - Component type: WebPart
   - Web part name: `BrokenLinkChecker`
   - Description: `Scans site pages for broken links`
   - Framework: React

2. **Replace generated files** with the provided files.

3. **Install PnP JS:**
   ```bash
   npm install @pnp/sp @pnp/logging --save
   ```

## 🔧 Development

### Local Testing

1. **Start the local workbench:**
   ```bash
   gulp serve
   ```

2. **Update serve.json** with your SharePoint site URL:
   ```json
   {
     "pageUrl": "https://yourtenant.sharepoint.com/sites/yoursite/_layouts/workbench.aspx"
   }
   ```

3. **Open the SharePoint workbench** in your browser (automatically opens at https://localhost:4321)

4. **Add the web part** to the page:
   - Click the "+" icon
   - Search for "Broken Link Checker"
   - Add to page

### Testing Authentication

Test in the local workbench with your SharePoint site URL to verify:
- Current user detection
- Permission checks
- Link scanning
- Error handling

## 📦 Build & Package

### Build the Solution

```bash
# Development build
gulp bundle

# Production build
gulp bundle --ship
```

### Create SharePoint Package

```bash
# Development package
gulp package-solution

# Production package
gulp package-solution --ship
```

The `.sppkg` file will be created in `sharepoint/solution/` folder.

## 🚢 Deployment

### Deploy to SharePoint App Catalog

1. **Navigate to App Catalog:**
   - Go to SharePoint Admin Center
   - Click "More features"
   - Under "Apps", click "Open"
   - Click "App Catalog"

2. **Upload the package:**
   - Drag and drop `broken-link-checker.sppkg` to "Apps for SharePoint"
   - Check "Make this solution available to all sites"
   - Click "Deploy"

3. **Add to your site:**
   - Go to your SharePoint site
   - Click Settings (gear icon) → "Add an app"
   - Click "From Your Organization"
   - Find "Broken Link Checker"
   - Click "Add"

4. **Add web part to a page:**
   - Create or edit a page
   - Click "+" to add a web part
   - Search for "Broken Link Checker"
   - Add to page
   - Publish the page

## 🔐 Permissions & Security

### Required Permissions

The web part requires:
- **User permission level:** Read (minimum)
- **Site collection access:** User must have access to the site being scanned
- **No special app permissions** needed

### What the Web Part Can Access

✅ **Can access:**
- Pages the current user has Read access to
- Links within the same SharePoint tenant
- User's own profile information

❌ **Cannot access:**
- Pages user doesn't have permission to read
- Sites in other tenants
- Most external websites (CORS restrictions)

## 📋 File Placement Guide

### Where to put each file:

```
/package.json                           → Root
/tsconfig.json                          → Root
/config/config.json                     → config folder
/config/package-solution.json           → config folder
/config/serve.json                      → config folder

/src/webparts/brokenLinkChecker/
  ├── BrokenLinkCheckerWebPart.ts       → webparts/brokenLinkChecker
  ├── BrokenLinkCheckerWebPart.manifest.json → webparts/brokenLinkChecker
  ├── components/
  │   ├── BrokenLinkChecker.tsx         → components folder
  │   ├── BrokenLinkChecker.module.scss → components folder
  │   ├── IBrokenLinkCheckerProps.ts    → components folder
  │   └── IBrokenLinkCheckerState.ts    → components folder
  └── loc/
      ├── en-us.js                      → loc folder
      └── mystrings.d.ts                → loc folder
```

## 🔍 Troubleshooting

### Common Issues

**Issue:** `Cannot find module '@pnp/sp'`
```bash
npm install @pnp/sp @pnp/logging --save
```

**Issue:** `gulp: command not found`
```bash
npm install -g gulp-cli
```

**Issue:** TypeScript errors about Office UI Fabric
```bash
npm install office-ui-fabric-react@7.204.0 --save
```

**Issue:** Certificate trust errors
```bash
gulp trust-dev-cert
```

**Issue:** Port 4321 already in use
- Kill the process using port 4321, or
- Change port in `config/serve.json`

### Build Errors

**Clean and rebuild:**
```bash
gulp clean
npm install
gulp bundle --ship
gulp package-solution --ship
```

## 🧪 Testing Checklist

Before deployment, test:

- [ ] Web part loads without errors
- [ ] Current user email displays correctly
- [ ] Permission check works (try on a site without access)
- [ ] Scan button starts scanning
- [ ] Progress indicator shows
- [ ] Results display in table
- [ ] Broken links are identified correctly
- [ ] Working links show as working
- [ ] Export to CSV works
- [ ] Filters work (show only broken, internal/external)
- [ ] Error messages display properly

## 📝 Customization

### Change Web Part Icon

Edit `BrokenLinkCheckerWebPart.manifest.json`:
```json
{
  "officeFabricIconFontName": "Link"  // Change to any Fluent UI icon
}
```

### Change Web Part Title

Edit `BrokenLinkCheckerWebPart.manifest.json`:
```json
{
  "title": { "default": "Your Custom Title" }
}
```

### Modify Scan Delay

In `BrokenLinkChecker.tsx`, find:
```typescript
await this.delay(100);  // Change milliseconds
```

## 🔄 Updates & Maintenance

### Updating the Solution

1. Make code changes
2. Increment version in `package-solution.json`
3. Build and package:
   ```bash
   gulp clean
   gulp bundle --ship
   gulp package-solution --ship
   ```
4. Upload new `.sppkg` to App Catalog
5. Click "Replace" when prompted

### Version Management

Update version in `config/package-solution.json`:
```json
{
  "solution": {
    "version": "1.0.1.0"  // Increment for updates
  }
}
```

## 📚 Additional Resources

- [SPFx Documentation](https://docs.microsoft.com/en-us/sharepoint/dev/spfx/sharepoint-framework-overview)
- [PnP JS Documentation](https://pnp.github.io/pnpjs/)
- [Office UI Fabric React](https://developer.microsoft.com/en-us/fluentui#/controls/web)
- [SPFx Samples](https://github.com/pnp/sp-dev-fx-webparts)

## 💡 Tips

1. **Always test locally first** before deploying to production
2. **Use version control** (Git) to track changes
3. **Keep dependencies updated** for security patches
4. **Monitor SharePoint throttling** - add delays if needed
5. **Test with different user permissions** to ensure proper error handling

## ✅ Deployment Checklist

Before deploying to production:

- [ ] Code tested locally
- [ ] All TypeScript errors resolved
- [ ] Production build successful
- [ ] Package created successfully
- [ ] Tested on test site collection
- [ ] Error handling verified
- [ ] Performance tested with large site
- [ ] Documentation updated
- [ ] Version number incremented
- [ ] Ready for App Catalog upload
