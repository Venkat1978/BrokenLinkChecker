# SPFx Broken Link Checker - Authentication Guide

## 🔐 Authentication Overview

This SPFx web part uses **built-in SharePoint authentication**. No custom authentication code is required!

## How Authentication Works

### 1. **Automatic Authentication**
- The user is already authenticated when they access SharePoint
- SPFx automatically provides an authenticated context via `this.context`
- All SharePoint API calls inherit the current user's identity and permissions

### 2. **Permission Model**
The web part runs with the **current user's permissions**:
- ✅ User can scan any site they have **Read** access to
- ❌ User cannot scan sites they don't have access to
- The web part respects SharePoint's security model

### 3. **No API Keys or Secrets Needed**
- No client secrets
- No app passwords
- No OAuth tokens to manage
- Everything is handled by SharePoint Framework

## Authentication Methods Used

### Method 1: SPHttpClient (Recommended for Internal SharePoint Links)

```typescript
// Automatically authenticated as current user
const response = await this.props.context.spHttpClient.get(
  url,
  SPHttpClient.configurations.v1
);
```

**Benefits:**
- ✅ Fully authenticated
- ✅ Respects user permissions
- ✅ No CORS issues
- ✅ Works for all SharePoint resources

### Method 2: PnP JS Library (For SharePoint REST API)

```typescript
// Initialize with SPFx context (authenticated)
import { spfi, SPFx } from '@pnp/sp';

const sp = spfi().using(SPFx(this.props.context));

// All calls are authenticated as current user
const items = await sp.web.lists
  .getByTitle('Site Pages')
  .items();
```

**Benefits:**
- ✅ Simplified SharePoint operations
- ✅ Automatic authentication
- ✅ Type-safe
- ✅ Built-in error handling

### Method 3: Fetch API (For External Links - Limited)

```typescript
// External links - no authentication possible due to CORS
const response = await fetch(externalUrl, {
  method: 'HEAD',
  mode: 'no-cors'
});
```

**Limitations:**
- ⚠️ CORS blocks most external sites
- ⚠️ Cannot get HTTP status codes
- ⚠️ Can only detect network failures

## Permission Checks Implemented

### 1. **Check User Has Access**

```typescript
private async checkUserPermissions(): Promise<void> {
  try {
    // Get current user (proves authentication works)
    const currentUser = await this.sp.web.currentUser();
    
    // Try to read Site Pages library (proves read permission)
    await this.sp.web.lists
      .getByTitle('Site Pages')
      .items
      .top(1)();
      
    this.setState({ hasPermission: true });
    
  } catch (error) {
    if (error.status === 403) {
      // User doesn't have permission
      this.setState({ hasPermission: false });
    }
  }
}
```

### 2. **Handle Permission Errors Gracefully**

```typescript
private handleScanError(error: any): void {
  if (error.status === 401) {
    // Authentication failed
    return 'Authentication failed. Please refresh the page.';
  } else if (error.status === 403) {
    // Access denied
    return 'Access denied. You do not have permission.';
  } else if (error.status === 429) {
    // Throttled
    return 'Too many requests. Please wait and try again.';
  }
}
```

## Security Best Practices

### ✅ What This Web Part Does RIGHT

1. **Uses SPFx Context** - All authenticated calls go through SPFx
2. **Respects Permissions** - Cannot bypass SharePoint security
3. **No Stored Credentials** - No secrets in code or config
4. **User-Scoped** - Each user sees only what they can access
5. **Error Handling** - Gracefully handles permission errors

### ❌ What This Web Part CANNOT Do

1. **Cannot elevate permissions** - Runs as current user only
2. **Cannot access restricted sites** - Respects SharePoint security
3. **Cannot bypass CORS** - External links are limited
4. **Cannot use app-only permissions** - User context only

## External Link Checking Options

### Option 1: Client-Side Only (Current Implementation)
```typescript
// Limited - CORS blocks most sites
await fetch(externalUrl, { mode: 'no-cors' });
// Result: "Unable to verify - CORS policy"
```

### Option 2: Azure Function (Recommended)
Create a server-side Azure Function to check external links:

```typescript
// Azure Function (server-side - no CORS issues)
export async function run(context, req) {
  const { url } = req.body;
  
  try {
    const response = await axios.head(url, { timeout: 5000 });
    return {
      status: response.status,
      message: 'Working'
    };
  } catch (error) {
    return {
      status: error.response?.status || 0,
      message: 'Broken'
    };
  }
}
```

**Call from SPFx:**
```typescript
const response = await this.props.context.httpClient.post(
  'https://your-function.azurewebsites.net/api/CheckLink',
  HttpClient.configurations.v1,
  {
    body: JSON.stringify({ url: externalUrl })
  }
);
```

### Option 3: Mark External Links Only
```typescript
// Don't check external links, just identify them
if (this.isExternalLink(url)) {
  return {
    status: 'external',
    message: 'External link - not verified'
  };
}
```

## Cross-Site Collection Scanning

### Scanning Other Site Collections

The web part can scan other site collections **IF** the user has access:

```typescript
// User needs Read permission on the target site
const targetSiteUrl = 'https://tenant.sharepoint.com/sites/OtherSite';

// This will work if user has access
const sp = spfi(targetSiteUrl).using(SPFx(this.props.context));
const items = await sp.web.lists.getByTitle('Site Pages').items();
```

### Handling Access Denied

```typescript
try {
  const items = await sp.web.lists.getByTitle('Site Pages').items();
} catch (error) {
  if (error.status === 403) {
    // Show user-friendly message
    this.setState({
      errorMessage: 'You do not have access to this site collection.'
    });
  }
}
```

## Microsoft Graph API (Advanced)

If you need **app-level permissions** instead of user permissions:

### 1. Request Permissions in package-solution.json

```json
{
  "solution": {
    "name": "broken-link-checker",
    "webApiPermissionRequests": [
      {
        "resource": "Microsoft Graph",
        "scope": "Sites.Read.All"
      }
    ]
  }
}
```

### 2. Admin Approval Required

After deployment:
1. Go to **SharePoint Admin Center**
2. Navigate to **Advanced → API access**
3. Approve the permission request

### 3. Use Graph in Code

```typescript
import { MSGraphClientV3 } from '@microsoft/sp-http';

const graphClient: MSGraphClientV3 = await this.props.context.msGraphClientFactory.getClient('3');

const sites = await graphClient
  .api('/sites')
  .get();
```

## Deployment Checklist

- [ ] No credentials in code
- [ ] No API keys in config files
- [ ] Using SPFx context for all SharePoint calls
- [ ] Permission checks implemented
- [ ] Error handling for 401/403/429
- [ ] User informed of their access level
- [ ] External links handled appropriately

## Testing Authentication

### Test 1: Current User
```typescript
const user = await sp.web.currentUser();
console.log('Authenticated as:', user.Email);
```

### Test 2: Permission Check
```typescript
try {
  await sp.web.lists.getByTitle('Site Pages').items.top(1)();
  console.log('✅ User has read access');
} catch (error) {
  console.log('❌ Access denied:', error.status);
}
```

### Test 3: Cross-Site Access
```typescript
const otherSite = spfi('https://tenant.sharepoint.com/sites/Other')
  .using(SPFx(this.props.context));
  
try {
  await otherSite.web.lists.getByTitle('Site Pages').items.top(1)();
  console.log('✅ Cross-site access works');
} catch {
  console.log('❌ No access to other site');
}
```

## Troubleshooting

### Issue: "Access Denied" Error
**Solution:** User doesn't have Read permission. Grant access in SharePoint.

### Issue: "Authentication Failed"
**Solution:** Token expired. Refresh the page.

### Issue: "Cannot verify external links"
**Solution:** This is expected due to CORS. Use Azure Function or mark as "external".

### Issue: "Too Many Requests (429)"
**Solution:** SharePoint throttling. Add delays between requests (already implemented).

## Summary

✅ **Authentication is automatic** - No code needed  
✅ **Uses current user's identity** - Respects permissions  
✅ **Secure by design** - Cannot bypass SharePoint security  
✅ **No secrets to manage** - SPFx handles everything  
⚠️ **External links limited** - CORS blocks verification  
⚠️ **User permissions only** - Cannot elevate access  

The web part is production-ready with proper authentication handling!
