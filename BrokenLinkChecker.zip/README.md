# Broken Link Checker - SPFx Web Part

A SharePoint Framework (SPFx) web part that scans all pages in a site collection to identify broken internal and external links.

## 🎯 Features

- ✅ Scans all pages in Site Pages library
- ✅ Checks both internal SharePoint links and external URLs
- ✅ Displays results in sortable table
- ✅ Exports results to CSV
- ✅ Shows current user and permission status
- ✅ Filters: Show only broken links, Internal/External
- ✅ Progress indicator during scanning
- ✅ Handles authentication automatically
- ✅ Graceful error handling for permissions

## 📸 Screenshots

The web part provides:
- **Scan Button** - Initiates link checking
- **Progress Bar** - Shows scanning status
- **Results Table** - Displays all found links with status
- **Filters** - Filter by link type or status
- **Export** - Download results as CSV

## 🔐 Authentication

**No setup required!** The web part uses SharePoint's built-in authentication:
- Runs with current user's permissions
- No API keys or secrets needed
- Respects SharePoint security model
- See [AUTHENTICATION_GUIDE.md](./AUTHENTICATION_GUIDE.md) for details

## 🚀 Quick Start

### Installation

1. Clone or download the project files
2. Install dependencies:
   ```bash
   npm install
   ```
3. Trust development certificate:
   ```bash
   gulp trust-dev-cert
   ```
4. Start local server:
   ```bash
   gulp serve
   ```

### Deployment

1. Build production package:
   ```bash
   gulp bundle --ship
   gulp package-solution --ship
   ```
2. Upload `.sppkg` file to SharePoint App Catalog
3. Add web part to any SharePoint page

See [SETUP_GUIDE.md](./SETUP_GUIDE.md) for detailed instructions.

## 📁 Project Structure

```
broken-link-checker/
├── config/                              # SPFx configuration files
│   ├── config.json                      # Build configuration
│   ├── package-solution.json            # SharePoint package settings
│   └── serve.json                       # Development server settings
├── src/
│   └── webparts/
│       └── brokenLinkChecker/
│           ├── components/
│           │   ├── BrokenLinkChecker.tsx           # Main React component
│           │   ├── BrokenLinkChecker.module.scss   # Styles
│           │   ├── IBrokenLinkCheckerProps.ts      # Props interface
│           │   └── IBrokenLinkCheckerState.ts      # State interface
│           ├── loc/
│           │   ├── en-us.js                        # Localization strings
│           │   └── mystrings.d.ts                  # String type definitions
│           ├── BrokenLinkCheckerWebPart.ts         # Web part class
│           └── BrokenLinkCheckerWebPart.manifest.json  # Web part manifest
├── package.json                         # npm dependencies
├── tsconfig.json                        # TypeScript configuration
├── gulpfile.js                          # Gulp build tasks
├── SETUP_GUIDE.md                       # Complete setup instructions
├── AUTHENTICATION_GUIDE.md              # Authentication details
└── README.md                            # This file
```

## 🔧 Requirements

- **Node.js**: v16.x or v18.x
- **npm**: v8.x
- **SharePoint Online**
- **User Permissions**: Read access to Site Pages library

## 📚 Key Technologies

- **SharePoint Framework (SPFx)** 1.18.2
- **React** 17.0.1
- **TypeScript** 4.7.4
- **Office UI Fabric React** 7.204.0
- **PnP JS** 3.12.0

## 🎨 Components

### Main Component: BrokenLinkChecker.tsx

The main React component that handles:
- User permission checking
- Page scanning
- Link extraction and validation
- Results display and filtering
- CSV export

### Interfaces

- **IBrokenLinkCheckerProps** - Component props (context)
- **IBrokenLinkCheckerState** - Component state (results, scanning status)
- **ILinkResult** - Individual link result data
- **LinkStatus** - Link status type ('working' | 'broken' | 'warning' | 'error' | 'external')

## 🔍 How It Works

1. **Permission Check**: Verifies user has Read access to Site Pages library
2. **Page Retrieval**: Gets all pages using PnP JS / SharePoint REST API
3. **Link Extraction**: Parses page content to find all `<a>` tags
4. **Link Validation**:
   - **Internal links**: Uses authenticated SPHttpClient
   - **External links**: Attempts fetch (limited by CORS)
5. **Results Display**: Shows status, page name, link URL, status code
6. **Export**: Downloads results as CSV file

## ⚙️ Configuration

### Web Part Properties

Edit in `BrokenLinkCheckerWebPart.manifest.json`:
- Title and description
- Icon (Office UI Fabric icon name)
- Group placement

### Customization

- **Scan delay**: Modify `delay()` value in component
- **Results columns**: Update `getColumns()` method
- **Styling**: Edit `BrokenLinkChecker.module.scss`

## 📊 Results

The web part displays:
- **Status**: Working ✅ | Broken ❌ | Warning ⚠️ | External 🌐
- **Page Name**: Title of the page containing the link
- **Link URL**: The actual link being checked
- **Status Code**: HTTP status code (for internal links)
- **Message**: Detailed status message
- **Type**: Internal or External link

## 🚨 Limitations

### External Links
- CORS policy blocks status checking for most external sites
- External links are marked as "Unable to verify"
- **Solution**: Use Azure Function for server-side checking (see authentication guide)

### Permissions
- User can only scan sites they have access to
- Cannot elevate permissions
- Respects SharePoint security boundaries

### Throttling
- SharePoint may throttle excessive requests
- Built-in delays between link checks (100ms)
- Adjust if needed for large sites

## 🐛 Troubleshooting

### Common Issues

**"You do not have permission"**
- User needs Read access to the Site Pages library
- Grant permission in SharePoint

**"Authentication failed"**
- Token may have expired
- Refresh the page and try again

**"Too many requests (429)"**
- SharePoint throttling active
- Increase delay between requests
- Wait a few minutes and retry

**External links show "Unable to verify"**
- This is expected due to CORS
- Use Azure Function for accurate checking (optional)

## 🔄 Updates

To update the web part:

1. Make code changes
2. Update version in `config/package-solution.json`
3. Build: `gulp bundle --ship`
4. Package: `gulp package-solution --ship`
5. Upload new `.sppkg` to App Catalog
6. Replace existing package

## 📖 Documentation

- [SETUP_GUIDE.md](./SETUP_GUIDE.md) - Complete installation and deployment guide
- [AUTHENTICATION_GUIDE.md](./AUTHENTICATION_GUIDE.md) - How authentication works

## 🤝 Contributing

Suggestions for improvements:
1. Azure Function integration for external link checking
2. Multi-site collection scanning
3. Scheduled scanning with email reports
4. Historical tracking of broken links
5. Auto-fix suggestions for broken internal links

## 📝 License

This project is provided as-is for educational and commercial use.

## 👤 Author

Created for SharePoint Online environments using SPFx best practices.

## 🙏 Acknowledgments

- Microsoft SharePoint Framework
- PnP Community
- Office UI Fabric React

## 📞 Support

For issues or questions:
1. Check [SETUP_GUIDE.md](./SETUP_GUIDE.md)
2. Review [AUTHENTICATION_GUIDE.md](./AUTHENTICATION_GUIDE.md)
3. Check SPFx documentation
4. Review browser console for errors

---

**Happy Link Checking! 🔗✨**
