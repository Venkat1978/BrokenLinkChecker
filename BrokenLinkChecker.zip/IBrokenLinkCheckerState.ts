export type LinkStatus = 'working' | 'broken' | 'warning' | 'error' | 'external';

export interface ILinkResult {
  pageName: string;
  pageUrl: string;
  linkUrl: string;
  status: LinkStatus;
  statusCode: number;
  message: string;
  linkType: 'internal' | 'external';
}

export interface IBrokenLinkCheckerState {
  results: ILinkResult[];
  isScanning: boolean;
  progress: number;
  currentPage: string;
  totalPages: number;
  scannedPages: number;
  includeSubsites: boolean;
  showOnlyBroken: boolean;
  filterType: string;
  errorMessage: string;
  hasPermission: boolean;
  userEmail: string;
}
