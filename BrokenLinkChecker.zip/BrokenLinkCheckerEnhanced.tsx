import * as React from 'react';
import { IBrokenLinkCheckerProps } from './IBrokenLinkCheckerProps';
import { IBrokenLinkCheckerState, ILinkResult, LinkStatus } from './IBrokenLinkCheckerState';
import { 
  PrimaryButton, 
  DefaultButton,
  DetailsList, 
  IColumn, 
  ProgressIndicator,
  MessageBar,
  MessageBarType,
  Dropdown,
  IDropdownOption,
  Spinner,
  SpinnerSize,
  Stack,
  Icon
} from 'office-ui-fabric-react';
import { spfi, SPFx } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/site-users/web';
import styles from './BrokenLinkChecker.module.scss';

export default class BrokenLinkChecker extends React.Component<IBrokenLinkCheckerProps, IBrokenLinkCheckerState> {
  private sp: any;

  constructor(props: IBrokenLinkCheckerProps) {
    super(props);

    this.state = {
      results: [],
      isScanning: false,
      progress: 0,
      currentPage: '',
      totalPages: 0,
      scannedPages: 0,
      includeSubsites: false,
      showOnlyBroken: false,
      filterType: 'all',
      errorMessage: '',
      hasPermission: true,
      userEmail: ''
    };

    // Initialize PnP with SPFx context (authenticated)
    this.sp = spfi().using(SPFx(this.props.context));
  }

  public async componentDidMount(): Promise<void> {
    await this.checkUserPermissions();
  }

  /**
   * Check if current user has read permissions
   */
  private async checkUserPermissions(): Promise<void> {
    try {
      // Get current user
      const currentUser = await this.sp.web.currentUser();
      
      this.setState({ 
        userEmail: currentUser.Email,
        hasPermission: true 
      });

      // Try to read Site Pages library to verify permissions
      await this.sp.web.lists
        .getByTitle('Site Pages')
        .items
        .select('Id')
        .top(1)();

    } catch (error) {
      if (error.status === 403) {
        this.setState({
          hasPermission: false,
          errorMessage: 'You do not have permission to read pages in this site. Please contact your administrator.'
        });
      } else if (error.status === 404) {
        this.setState({
          errorMessage: 'Site Pages library not found. This web part requires a Site Pages library.'
        });
      } else {
        this.setState({
          errorMessage: `Authentication error: ${error.message}`
        });
      }
    }
  }

  /**
   * Start scanning for broken links
   */
  private scanLinks = async (): Promise<void> => {
    if (!this.state.hasPermission) {
      this.setState({
        errorMessage: 'You do not have sufficient permissions to scan this site.'
      });
      return;
    }

    this.setState({ 
      isScanning: true, 
      results: [], 
      progress: 0,
      scannedPages: 0,
      errorMessage: ''
    });

    try {
      const pages = await this.getPages();
      this.setState({ totalPages: pages.length });

      const allResults: ILinkResult[] = [];

      for (let i = 0; i < pages.length; i++) {
        const page = pages[i];
        this.setState({ 
          currentPage: page.Title,
          scannedPages: i + 1,
          progress: ((i + 1) / pages.length) * 100
        });

        const links = await this.extractLinks(page);
        const checkedLinks = await this.checkLinks(links, page.Title, page.FileRef);

        allResults.push(...checkedLinks);
      }

      this.setState({ 
        results: allResults,
        isScanning: false,
        progress: 100
      });

    } catch (error) {
      this.handleScanError(error);
    }
  }

  /**
   * Handle errors during scanning
   */
  private handleScanError(error: any): void {
    let errorMessage = 'An error occurred while scanning.';

    if (error.status === 401) {
      errorMessage = 'Authentication failed. Please refresh the page and try again.';
    } else if (error.status === 403) {
      errorMessage = 'Access denied. You do not have permission to access some pages.';
    } else if (error.status === 429) {
      errorMessage = 'Too many requests. SharePoint is throttling. Please wait and try again.';
    } else if (error.message) {
      errorMessage = `Error: ${error.message}`;
    }

    this.setState({
      isScanning: false,
      errorMessage: errorMessage
    });
  }

  /**
   * Get all pages from Site Pages library
   * Uses authenticated SharePoint context
   */
  private async getPages(): Promise<any[]> {
    try {
      const items = await this.sp.web.lists
        .getByTitle('Site Pages')
        .items
        .select('Id', 'Title', 'FileRef', 'CanvasContent1', 'File/ServerRelativeUrl')
        .expand('File')
        .filter("FSObjType eq 0")  // Only files, not folders
        .top(5000)();

      return items;
    } catch (error) {
      if (error.status === 403) {
        throw new Error('You do not have permission to read pages from this site.');
      }
      throw error;
    }
  }

  /**
   * Extract links from page content
   */
  private extractLinks(page: any): string[] {
    const links: string[] = [];
    
    if (page.CanvasContent1) {
      try {
        const canvasContent = JSON.parse(page.CanvasContent1);
        
        canvasContent.forEach((control: any) => {
          if (control.innerHTML) {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = control.innerHTML;
            const anchorTags = tempDiv.getElementsByTagName('a');
            
            for (let i = 0; i < anchorTags.length; i++) {
              const href = anchorTags[i].getAttribute('href');
              if (href && href.trim() !== '') {
                links.push(href);
              }
            }
          }
        });
      } catch (e) {
        console.error('Error parsing canvas content:', e);
      }
    }

    return [...new Set(links)]; // Remove duplicates
  }

  /**
   * Check if links are broken
   */
  private async checkLinks(links: string[], pageTitle: string, pageUrl: string): Promise<ILinkResult[]> {
    const results: ILinkResult[] = [];
    const baseUrl = this.props.context.pageContext.web.absoluteUrl;

    for (const link of links) {
      const result = await this.checkSingleLink(link, baseUrl);
      
      results.push({
        pageName: pageTitle,
        pageUrl: pageUrl,
        linkUrl: link,
        status: result.status,
        statusCode: result.statusCode,
        message: result.message,
        linkType: this.getLinkType(link, baseUrl)
      });

      // Small delay to avoid throttling
      await this.delay(100);
    }

    return results;
  }

  /**
   * Check a single link
   */
  private async checkSingleLink(url: string, baseUrl: string): Promise<{ status: LinkStatus, statusCode: number, message: string }> {
    try {
      // Handle relative URLs
      let fullUrl = url;
      if (url.startsWith('/')) {
        const origin = new URL(baseUrl).origin;
        fullUrl = origin + url;
      } else if (!url.startsWith('http')) {
        fullUrl = baseUrl + '/' + url;
      }

      // Internal SharePoint link - use authenticated SPHttpClient
      if (fullUrl.toLowerCase().includes(window.location.hostname.toLowerCase())) {
        return await this.checkInternalLink(fullUrl);
      } else {
        // External link - limited checking due to CORS
        return await this.checkExternalLink(fullUrl);
      }

    } catch (error) {
      return {
        status: 'error',
        statusCode: 0,
        message: `Error: ${error.message}`
      };
    }
  }

  /**
   * Check internal SharePoint link using authenticated context
   */
  private async checkInternalLink(url: string): Promise<{ status: LinkStatus, statusCode: number, message: string }> {
    try {
      // Use SPHttpClient for authenticated requests
      const response = await this.props.context.spHttpClient.get(
        url,
        1, // SPHttpClient.configurations.v1
        {
          headers: {
            'Accept': 'application/json;odata=nometadata',
            'odata-version': ''
          }
        }
      );

      if (response.ok) {
        return {
          status: 'working',
          statusCode: response.status,
          message: 'Link is working'
        };
      } else if (response.status === 404) {
        return {
          status: 'broken',
          statusCode: 404,
          message: 'Page not found (404)'
        };
      } else if (response.status === 403) {
        return {
          status: 'warning',
          statusCode: 403,
          message: 'Access denied (403) - You may not have permission'
        };
      } else {
        return {
          status: 'broken',
          statusCode: response.status,
          message: `HTTP ${response.status}`
        };
      }
    } catch (error) {
      return {
        status: 'error',
        statusCode: 0,
        message: `Error checking link: ${error.message}`
      };
    }
  }

  /**
   * Check external link (limited due to CORS)
   */
  private async checkExternalLink(url: string): Promise<{ status: LinkStatus, statusCode: number, message: string }> {
    try {
      // Use no-cors mode - we won't get status code but can detect complete failures
      const response = await fetch(url, {
        method: 'HEAD',
        mode: 'no-cors',
        cache: 'no-cache'
      });

      return {
        status: 'external',
        statusCode: 0,
        message: 'External link - Unable to verify due to CORS policy'
      };
    } catch (error) {
      // Network error - link might be broken
      return {
        status: 'warning',
        statusCode: 0,
        message: 'External link - Network error (possibly broken)'
      };
    }
  }

  /**
   * Determine link type
   */
  private getLinkType(url: string, baseUrl: string): 'internal' | 'external' {
    if (url.startsWith('/') || url.startsWith(baseUrl) || !url.startsWith('http')) {
      return 'internal';
    }
    return 'external';
  }

  /**
   * Utility delay function
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Export results to CSV
   */
  private exportToCSV = (): void => {
    const filteredResults = this.getFilteredResults();
    
    const csvContent = [
      ['Page Name', 'Page URL', 'Link URL', 'Status', 'Status Code', 'Message', 'Link Type'].join(','),
      ...filteredResults.map(r => [
        `"${r.pageName}"`,
        `"${r.pageUrl}"`,
        `"${r.linkUrl}"`,
        r.status,
        r.statusCode,
        `"${r.message}"`,
        r.linkType
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `broken-links-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  }

  /**
   * Get filtered results based on current filters
   */
  private getFilteredResults(): ILinkResult[] {
    let filtered = this.state.results;

    if (this.state.showOnlyBroken) {
      filtered = filtered.filter(r => r.status === 'broken' || r.status === 'error');
    }

    if (this.state.filterType !== 'all') {
      filtered = filtered.filter(r => r.linkType === this.state.filterType);
    }

    return filtered;
  }

  /**
   * Render columns for DetailsList
   */
  private getColumns(): IColumn[] {
    return [
      {
        key: 'status',
        name: 'Status',
        fieldName: 'status',
        minWidth: 80,
        maxWidth: 100,
        onRender: (item: ILinkResult) => {
          const iconName = item.status === 'working' ? 'CheckMark' : 
                          item.status === 'broken' ? 'Cancel' :
                          item.status === 'warning' ? 'Warning' :
                          item.status === 'external' ? 'Globe' : 'Error';
          const iconColor = item.status === 'working' ? '#107c10' : 
                           item.status === 'broken' ? '#d13438' :
                           item.status === 'warning' ? '#ff8c00' :
                           item.status === 'external' ? '#0078d4' : '#605e5c';
          
          return (
            <Stack horizontal tokens={{ childrenGap: 5 }} verticalAlign="center">
              <Icon iconName={iconName} style={{ color: iconColor }} />
              <span>{item.status}</span>
            </Stack>
          );
        }
      },
      {
        key: 'pageName',
        name: 'Page Name',
        fieldName: 'pageName',
        minWidth: 150,
        maxWidth: 250,
        isResizable: true
      },
      {
        key: 'linkUrl',
        name: 'Link URL',
        fieldName: 'linkUrl',
        minWidth: 250,
        maxWidth: 400,
        isResizable: true,
        onRender: (item: ILinkResult) => (
          <a href={item.linkUrl} target="_blank" rel="noopener noreferrer">
            {item.linkUrl}
          </a>
        )
      },
      {
        key: 'statusCode',
        name: 'Code',
        fieldName: 'statusCode',
        minWidth: 50,
        maxWidth: 70
      },
      {
        key: 'message',
        name: 'Message',
        fieldName: 'message',
        minWidth: 200,
        maxWidth: 300,
        isResizable: true
      },
      {
        key: 'linkType',
        name: 'Type',
        fieldName: 'linkType',
        minWidth: 80,
        maxWidth: 100
      }
    ];
  }

  public render(): React.ReactElement<IBrokenLinkCheckerProps> {
    const filteredResults = this.getFilteredResults();
    const brokenCount = this.state.results.filter(r => r.status === 'broken').length;
    const warningCount = this.state.results.filter(r => r.status === 'warning' || r.status === 'error').length;

    return (
      <div className={styles.brokenLinkChecker}>
        <div className={styles.container}>
          <h2>Broken Link Checker</h2>
          
          {!this.state.hasPermission && (
            <MessageBar messageBarType={MessageBarType.error}>
              You do not have permission to scan this site. Please contact your administrator.
            </MessageBar>
          )}

          {this.state.errorMessage && (
            <MessageBar 
              messageBarType={MessageBarType.error}
              onDismiss={() => this.setState({ errorMessage: '' })}
            >
              {this.state.errorMessage}
            </MessageBar>
          )}

          {this.state.userEmail && (
            <MessageBar messageBarType={MessageBarType.info}>
              Scanning as: {this.state.userEmail}
            </MessageBar>
          )}

          <Stack tokens={{ childrenGap: 15 }}>
            <Stack horizontal tokens={{ childrenGap: 10 }}>
              <PrimaryButton 
                text="Scan for Broken Links" 
                onClick={this.scanLinks}
                disabled={this.state.isScanning || !this.state.hasPermission}
              />
              
              {this.state.results.length > 0 && (
                <DefaultButton 
                  text="Export to CSV" 
                  onClick={this.exportToCSV}
                  iconProps={{ iconName: 'Download' }}
                />
              )}
            </Stack>

            {this.state.isScanning && (
              <Stack tokens={{ childrenGap: 10 }}>
                <ProgressIndicator 
                  label={`Scanning: ${this.state.currentPage}`}
                  description={`${this.state.scannedPages} of ${this.state.totalPages} pages scanned`}
                  percentComplete={this.state.progress / 100}
                />
                <Spinner size={SpinnerSize.large} label="Checking links..." />
              </Stack>
            )}

            {this.state.results.length > 0 && !this.state.isScanning && (
              <>
                <Stack horizontal tokens={{ childrenGap: 15 }}>
                  <MessageBar>
                    Total Links: {this.state.results.length} | 
                    Broken: {brokenCount} | 
                    Warnings: {warningCount}
                  </MessageBar>
                </Stack>

                <Stack horizontal tokens={{ childrenGap: 10 }}>
                  <Dropdown
                    label="Filter by Type"
                    selectedKey={this.state.filterType}
                    onChange={(e, option) => this.setState({ filterType: option.key as string })}
                    options={[
                      { key: 'all', text: 'All Links' },
                      { key: 'internal', text: 'Internal Only' },
                      { key: 'external', text: 'External Only' }
                    ]}
                    styles={{ root: { width: 200 } }}
                  />

                  <DefaultButton
                    text={this.state.showOnlyBroken ? 'Show All Links' : 'Show Only Broken'}
                    onClick={() => this.setState({ showOnlyBroken: !this.state.showOnlyBroken })}
                    toggle
                    checked={this.state.showOnlyBroken}
                  />
                </Stack>

                <DetailsList
                  items={filteredResults}
                  columns={this.getColumns()}
                  selectionMode={0}
                  layoutMode={1}
                  isHeaderVisible={true}
                />
              </>
            )}
          </Stack>
        </div>
      </div>
    );
  }
}
