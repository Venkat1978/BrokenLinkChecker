declare interface IBrokenLinkCheckerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BrokenLinkCheckerWebPartStrings' {
  const strings: IBrokenLinkCheckerWebPartStrings;
  export = strings;
}
