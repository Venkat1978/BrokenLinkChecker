define([], function() {
  return {
    "PropertyPaneDescription": "Broken Link Checker Settings",
    "BasicGroupName": "Configuration",
    "DescriptionFieldLabel": "Description"
  }
});
